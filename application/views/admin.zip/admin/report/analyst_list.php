<?php $this->load->view('admin/header.php'); ?>

<?php $this->load->view('admin/footer.php'); ?>