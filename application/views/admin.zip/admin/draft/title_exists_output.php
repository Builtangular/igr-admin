<?php  if($message) { ?>
<div class="row">    
   <?php  print_r($message); ?>
</div>
<?php  } ?>